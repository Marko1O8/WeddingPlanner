package WeddingPlanner;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Deleted extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	static String[][] allData;
	static String[] data;
	static String display;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Deleted frame = new Deleted();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Deleted() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 179);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
		
		allData = weddingPlan.GetAllDeleted();
		
		JComboBox<String> cbDeleted = new JComboBox<>();
		cbDeleted.setBounds(10, 11, 414, 22);
		
		for(int i = 0; i < allData.length; i++) {
			
			data = allData[i];
			display = data[0] + " " + data[1] + " " + data[2] + " " + data[3] + " " + data[4] + " " + data[5] + " " + data[6];
			cbDeleted.addItem(display);
		}
		
		contentPane.add(cbDeleted);
		
		JButton btnUndelete = new JButton("Undelete");
		btnUndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
				
				String key;
				char firstChar;
				
				String selectedItem = (String) cbDeleted.getSelectedItem();
				
				firstChar = selectedItem.charAt(0);
				key = Character.toString(firstChar);
				
				data = weddingPlan.GetDeleted(key);
				weddingPlan.SaveRecord(data);
				weddingPlan.DeleteCopy(key);
				
                if (selectedItem != null) {
                    JOptionPane.showMessageDialog(Deleted.this, "Undelete " + selectedItem, "Undelete", JOptionPane.QUESTION_MESSAGE);
                }
                
                dispose();
				
			}
		});
		btnUndelete.setBounds(71, 106, 89, 23);
		contentPane.add(btnUndelete);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnCancel.setBounds(248, 106, 89, 23);
		contentPane.add(btnCancel);
	}
}
