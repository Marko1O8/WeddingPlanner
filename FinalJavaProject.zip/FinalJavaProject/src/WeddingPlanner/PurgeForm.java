package WeddingPlanner;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PurgeForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PurgeForm frame = new PurgeForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PurgeForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 375, 127);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPurge = new JLabel("Are You Sure You Want To Purge?");
		lblPurge.setBounds(89, 11, 223, 14);
		contentPane.add(lblPurge);
		
		JButton btnPurge = new JButton("PURGE!");
		btnPurge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				WeddingPlan weddingPlan = new WeddingPlan();
				
				weddingPlan.DeleteAllCopy(rootPaneCheckingEnabled);
				dispose();
				
			}
		});
		btnPurge.setBounds(46, 59, 89, 23);
		contentPane.add(btnPurge);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
			}
		});
		btnCancel.setBounds(223, 59, 89, 23);
		contentPane.add(btnCancel);
	}
}
