package WeddingPlanner;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class DisplayForm extends JFrame {

    static int[] colWidths = { 50, 200, 150, 100, 150, 125, 125, 50 };
    static String[][] thePlanner;
    static String[] tableData = new String[WeddingPlan.FieldHeads.length];

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DisplayForm frame = new DisplayForm();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public DisplayForm() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 790, 421);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, 774, 346);
        contentPane.add(scrollPane);

        table = new JTable();
        DefaultTableModel model = new DefaultTableModel();
        table.setModel(model);

        for (String head : WeddingPlan.FieldHeads) {
            model.addColumn(head);
        }
        
        WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();

        try {
            thePlanner = weddingPlan.GetAllCompanies();
            for (String[] row : thePlanner) {
                for (int i = 0; i < row.length - 1; i++) {
                    tableData[i] = row[i];
                }
                tableData[row.length - 1] = row[row.length - 1];
                model.addRow(tableData);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        scrollPane.setViewportView(table);

        for (int i = 0; i < colWidths.length; i++) {
            if (i < model.getColumnCount()) {
                table.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);
            }
        }

        setLocationRelativeTo(null);
        setVisible(true);

        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
            	dispose();
            	
            }
        });
        btnExit.setBounds(342, 348, 89, 23);
        contentPane.add(btnExit);
    }
}
