package WeddingPlanner;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class WeddingPlan {

	private Connection connection = null; 
    private static final String DBName = "WeddingPlanner.db";

    public static final String[] FieldHeads = { "ID", "Name", "Service", "Phone#", "Address", "Estimated Cost", "Deal Name", "% Off" };
    public int[] FieldLens = { 5, 5, 15, 15, 5, 10, 10 };

  
    public static final String[] FieldNames = { "company_ID", "company_name", "service", "phone_Number", "address", "average_estimated_cost", "deals_ID" };

   
    public int[] DataTypes = { 0, 1, 1, 1, 1, 0, 0 }; // 0 -> No quotes, 1 -> Quotes needed
    public String keyName = FieldNames[0]; 
    public String tableName = "Companies";  

    public WeddingPlan() {
        DBConnect(DBName);
    }

    protected void finalize() throws Throwable {
        DBClose();
    }

    private void DBConnect(String DBName) {
    	try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
            String url = "jdbc:sqlite:" + DBName;
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to the database", e);
        }
    }

    private void DBClose() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException("Cannot close the database connection", e);
            }
        }
    }

    private String[][] GetData(String commandString) {
        String[][] data = null;
        int col;
        int row = 0;

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(commandString)) {

            // Determine the number of columns
            int cols = rs.getMetaData().getColumnCount();

            // Populate the data array
            data = new String[100][cols]; // Initialize with a reasonable size
            while (rs.next()) {
                if (row >= data.length) {
                    // Increase the size of the data array
                    String[][] newData = new String[data.length * 2][cols];
                    System.arraycopy(data, 0, newData, 0, data.length);
                    data = newData;
                }
                for (col = 0; col < cols; col++) {
                    data[row][col] = rs.getString(col + 1);
                }
                row++;
            }

            // Create a new data array with the exact size
            String[][] finalData = new String[row][cols];
            System.arraycopy(data, 0, finalData, 0, row);
            data = finalData;

        } catch (SQLException e) {
            throw new RuntimeException("Cannot get data from the database", e);
        }

        return data;
    }
//SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, deals_ID FROM Companies INNER JOIN Deals ON Companies.deals_ID = Deals.deals_ID ORDER BY company_ID
    public String[][] GetAllCompanies() {
        
    	String[][] data = null;
    	String commandString;
    	
    	commandString = "SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, description, percent_off FROM Companies, Deals WHERE Companies.deals_ID = Deals.deals_ID ORDER BY company_ID";

        data = GetData(commandString);
        
        return data;
    }

    public String[][] GetDeals() {
        String commandString = "SELECT * FROM Deals";

        return GetData(commandString);
    }

    public String[] GetARecord(String tableName, String keyName, String key) {
        String commandString;
        String[] Record = null;
        int col;

        commandString = "SELECT * FROM " + tableName + " WHERE " + keyName + " = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(commandString)) {
            pstmt.setString(1, key);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Record = new String[rs.getMetaData().getColumnCount()];
                for (col = 0; col < rs.getMetaData().getColumnCount(); col++)
                    Record[col] = rs.getString(col + 1);
            } else {
                Record = new String[1];
                Record[0] = "no record found";
            }
        } catch (SQLException e) {
            throw new RuntimeException("Cannot get a record from the database", e);
        }

        return Record;
    }

    public String[] GetRecord(String key) {
        return GetARecord(tableName, keyName, key);
    }

    public void DeleteARecord(String tableName, String keyName, String key) {
        String commandString = "DELETE FROM " + tableName + " WHERE " + keyName + " = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(commandString)) {
            pstmt.setString(1, key);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot delete a record from the database", e);
        }
    }

    public void DeleteRecord(String key) {
        DeleteARecord(tableName, keyName, key);
    }

    public boolean RecordExists(String tableName, String keyName, String key) {
        String commandString = "SELECT * FROM " + tableName + " WHERE " + keyName + " = ?";
        boolean exists = false;

        try (PreparedStatement pstmt = connection.prepareStatement(commandString)) {
            pstmt.setString(1, key);
            ResultSet rs = pstmt.executeQuery();
            exists = rs.next();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot check if a record exists in the database", e);
        }

        return exists;
    }

    private void InsertRecord(String tableName, String[] Record) {
        StringBuilder commandString = new StringBuilder("INSERT INTO " + tableName + " VALUES (");
        for (int i = 0; i < Record.length; i++) {
            if (DataTypes[i] == 1) {
                commandString.append("'");
            }
            commandString.append(Record[i]);
            if (DataTypes[i] == 1) {
                commandString.append("'");
            }
            if (i < Record.length - 1) {
                commandString.append(", ");
            }
        }
        commandString.append(")");

        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(commandString.toString());
        } catch (SQLException e) {
            throw new RuntimeException("Cannot insert a record into the database", e);
        }
    }

    public void UpdateRecord(String tableName, String keyName, String[] Record) {
        StringBuilder commandString = new StringBuilder("UPDATE " + tableName + " SET ");
        for (int i = 0; i < Record.length; i++) {
            commandString.append(FieldNames[i]).append(" = ");
            if (DataTypes[i] == 1) {
                commandString.append("'");
            }
            commandString.append(Record[i]);
            if (DataTypes[i] == 1) {
                commandString.append("'");
            }
            if (i < Record.length - 1) {
                commandString.append(", ");
            }
        }
        commandString.append(" WHERE ").append(keyName).append(" = ?");

        try (PreparedStatement pstmt = connection.prepareStatement(commandString.toString())) {
            pstmt.setString(1, Record[0]);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot update a record in the database", e);
        }
    }

    public void SaveRecord(String[] Record) {
        String key = Record[0];
        if (RecordExists(tableName, keyName, key)) {
            UpdateRecord(tableName, keyName, Record);
        } else {
            InsertRecord(tableName, Record);
        }
    }

    public String[][] GetCurrentCompany() {
        String commandString = "SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, deals_ID FROM Companies ORDER BY company_ID";

        return GetData(commandString);
    }

    public String[][] GetCompany() {
        String commandString = "SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, deals_ID FROM Companies ORDER BY company_ID";

        return GetData(commandString);
    }

    
    public static int GetLongestFieldLabel() {
        int i;
        int Longest = 0;

        for (i = 0; i < FieldHeads.length; i++)
            if (FieldHeads[i].length() > Longest)
                Longest = FieldHeads[i].length();

        return Longest;
    }

    public static String FindValue(String TheKey, String[][] values, int index) {
        int i;
        String key;
        String value;

        for (i = 0; i < values.length; i++) {
            key = values[i][0];
            value = values[i][index];
            if (TheKey.equals(key)) return value;
        }

        return "Not Found";
    }

    public String[][] GetAllDeleted() { //SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, deals_ID FROM Deleted INNER JOIN Deals ON Deleted.deals_ID = Deals.deals_ID ORDER BY company_ID";
        String commandString = "SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost, deals_ID FROM Deleted ORDER BY company_ID";

        return GetData(commandString);
    }

    public void SaveCopy(String[] Record) {
        InsertRecord("Deleted", Record);
    }

    public String[] GetDeleted(String key) {
        return GetARecord("Deleted", keyName, key);
    }

    public void DeleteCopy(String key) {
        DeleteARecord("Deleted", keyName, key);
    }

    public void DeleteAllCopy(boolean delete) {
        String commandString = "DELETE FROM Deleted";

        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(commandString);
        } catch (SQLException e) {
            throw new RuntimeException("Cannot delete all copies from the database", e);
        }
    }

    public String[][] GetCompanyDeleted() {
        String commandString = "SELECT company_ID, company_name, service, phone_Number, address, average_estimated_cost FROM Deleted ORDER BY company_ID";

        return GetData(commandString);
    }

}
