package WeddingPlanner;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class WeddingPlanner extends JFrame {

	private static final long serialVersionUID = 1L;
	public static WeddingPlan weddingPlan;
	private JPanel contentPane;
	private JTextField tfLookUp;
	private JTextField tfID;
	private JTextField tfName;
	private JTextField tfService;
	private JTextField tfPhone;
	private JTextField tfAverageCost;
	private JTextField tfDeals;
	private JTextField tfAddress;
	static String[] Record;
	static boolean RecordLoaded = false;
	public static Label KeyText = new Label();
	static int NumText;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WeddingPlanner frame = new WeddingPlanner();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static WeddingPlan getWeddingPlan() {
		
		if(weddingPlan == null)
			weddingPlan = new WeddingPlan();
		return weddingPlan;
		
	}

	/**
	 * Create the frame.
	 */
	public WeddingPlanner() {
		
	/*	System.out.println("Before initializeComponent");
		try {
		     weddingPlan = new WeddingPlan();
		} catch (Exception e) {
		    JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		    System.exit(1);
		}*/
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 416, 378);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 728, 22);
		contentPane.add(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		menuBar.add(mnFile);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(ABORT);
				
			}
		});
		mnFile.add(mntmExit);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(contentPane, "Hi my name is Marko Miserda I created this GUI Project. \n"
						+ "This project allows the user to modify a data base that is meant to help plan and book weddings.", "About", JOptionPane.PLAIN_MESSAGE);
				
			}
		});
		mnHelp.add(mntmAbout);
		
		JMenu mnDeleted = new JMenu("Deleted");
		menuBar.add(mnDeleted);
		
		JMenuItem mntmUndelete = new JMenuItem("Undelete");
		mntmUndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Deleted objDeleted = new Deleted();
				objDeleted.setVisible(true);
				
			}
		});
		mnDeleted.add(mntmUndelete);
		
		JMenuItem mntmPurge = new JMenuItem("Purge");
		mntmPurge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PurgeForm objPurge = new PurgeForm();
				objPurge.setVisible(true);
				
			}
		});
		mnDeleted.add(mntmPurge);
		
		JMenuItem mntmClearAll = new JMenuItem("Clear All");
		mntmClearAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tfLookUp.setText("");
				tfID.setText("");
				tfName.setText("");
				tfService.setText("");
				tfPhone.setText("");
				tfAddress.setText("");
				tfAverageCost.setText("");
				tfDeals.setText("");
				
			}
		});
		menuBar.add(mntmClearAll);
		
		JLabel lblCompanyLookUp = new JLabel("Company Look Up");
		lblCompanyLookUp.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCompanyLookUp.setBounds(10, 22, 108, 14);
		contentPane.add(lblCompanyLookUp);
		
		JLabel lblLookUpID = new JLabel("Look Up ID:");
		lblLookUpID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblLookUpID.setBounds(10, 47, 70, 14);
		contentPane.add(lblLookUpID);
		
		tfLookUp = new JTextField();
		tfLookUp.setFont(new Font("Tahoma", Font.PLAIN, 12));
		tfLookUp.setBounds(80, 45, 86, 20);
		contentPane.add(tfLookUp);
		tfLookUp.setColumns(10);
		
		JButton btnLookUp = new JButton("Look Up");
		btnLookUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = 0;
				String ID; 
				
				ID = tfLookUp.getText();
				
				i = Integer.parseInt(ID) - 1;
				 
				 WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
				 String[][] companies = weddingPlan.GetCompany();
				 
				 for (int j = 0; j < companies.length; j++) {
			            if (companies[j][0].equals(ID)) {
			                i = j;
			                break;
			            }
			        }
				 
                     tfID.setText(companies[i][0]);
                     tfName.setText(companies[i][1]);
                     tfService.setText(companies[i][2]);
                     tfPhone.setText(companies[i][3]);
                     tfAddress.setText(companies[i][4]);
                     tfAverageCost.setText(companies[i][5]);
                     tfDeals.setText(companies[i][6]);
			}
		});
		btnLookUp.setBounds(196, 44, 89, 23);
		contentPane.add(btnLookUp);
		
		JButton btnClearLookUp = new JButton("Clear");
		btnClearLookUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tfLookUp.setText("");
				
			}
		});
		btnClearLookUp.setBounds(295, 44, 89, 23);
		contentPane.add(btnClearLookUp);
		
		JLabel lblCompany = new JLabel("Company");
		lblCompany.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCompany.setBounds(10, 93, 55, 14);
		contentPane.add(lblCompany);
		
		JLabel lblCompanyID = new JLabel("ID:");
		lblCompanyID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCompanyID.setBounds(34, 118, 46, 14);
		contentPane.add(lblCompanyID);
		
		JLabel lblCompanyName = new JLabel("Name:");
		lblCompanyName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblCompanyName.setBounds(34, 143, 46, 14);
		contentPane.add(lblCompanyName);
		
		JLabel lblService = new JLabel("Service:");
		lblService.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblService.setBounds(34, 168, 46, 14);
		contentPane.add(lblService);
		
		JLabel lblPhoneNumber = new JLabel("Phone #:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPhoneNumber.setBounds(34, 193, 55, 14);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAddress.setBounds(34, 218, 55, 14);
		contentPane.add(lblAddress);
		
		tfID = new JTextField();
		tfID.setBounds(128, 116, 86, 20);
		contentPane.add(tfID);
		tfID.setColumns(10);
		
		tfName = new JTextField();
		tfName.setBounds(128, 141, 157, 20);
		contentPane.add(tfName);
		tfName.setColumns(10);
		
		tfService = new JTextField();
		tfService.setBounds(128, 166, 157, 20);
		contentPane.add(tfService);
		tfService.setColumns(10);
		
		tfPhone = new JTextField();
		tfPhone.setBounds(128, 190, 157, 20);
		contentPane.add(tfPhone);
		tfPhone.setColumns(10);
		
		tfAddress = new JTextField();
		tfAddress.setBounds(128, 216, 157, 20);
		contentPane.add(tfAddress);
		tfAddress.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
				 
				 Record = new String[]{tfID.getText(),
			                tfName.getText(),
			                tfService.getText(),
			                tfPhone.getText(),
			                tfAddress.getText(),
			                tfAverageCost.getText(),
			                tfDeals.getText()};
			        
				 
				 weddingPlan.SaveRecord(Record);
				 
				 clearDataEntry();
				
			}
		});
		btnAdd.setBounds(295, 114, 89, 23);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
				 
				 Record = new String[]{tfID.getText(),
			                tfName.getText(),
			                tfService.getText(),
			                tfPhone.getText(),
			                tfAddress.getText(),
			                tfAverageCost.getText(),
			                tfDeals.getText()};
			        
				 
				 weddingPlan.SaveRecord(Record);
				 
				 clearDataEntry();
				
			}
		});
		btnUpdate.setBounds(295, 139, 89, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				WeddingPlan weddingPlan = WeddingPlanner.getWeddingPlan();
				
				int i = 0;
				String ID, key; 
				
				ID = tfLookUp.getText();
				key = ID;
				
				Record = weddingPlan.GetRecord(key);
				    
				weddingPlan.SaveCopy(Record); //Yoooooooooo
	            weddingPlan.DeleteRecord(key);
	            clearDataEntry();
				
			}
		});
		btnDelete.setBounds(295, 164, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnClearCompany = new JButton("Clear");
		btnClearCompany.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				tfID.setText("");
				tfName.setText("");
				tfService.setText("");
				tfPhone.setText("");
				tfAddress.setText("");
				tfAverageCost.setText("");
				tfDeals.setText("");
				
			}
		});
		btnClearCompany.setBounds(295, 297, 89, 23);
		contentPane.add(btnClearCompany);
		
		JLabel lblAEC = new JLabel("Average Cost:");
		lblAEC.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAEC.setBounds(34, 243, 84, 14);
		contentPane.add(lblAEC);
		
		JLabel lblDeals = new JLabel("Deals:");
		lblDeals.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDeals.setBounds(34, 268, 46, 14);
		contentPane.add(lblDeals);
		
		tfAverageCost = new JTextField();
		tfAverageCost.setBounds(128, 241, 86, 20);
		contentPane.add(tfAverageCost);
		tfAverageCost.setColumns(10);
		
		tfDeals = new JTextField();
		tfDeals.setBounds(128, 266, 86, 20);
		contentPane.add(tfDeals);
		tfDeals.setColumns(10);
		
		JButton btnDisplay = new JButton("Display");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DisplayForm objDisplayForm = new DisplayForm();
			    objDisplayForm.setVisible(true);
				
			}
		});
		btnDisplay.setBounds(125, 297, 89, 23);
		contentPane.add(btnDisplay);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
	private void clearDataEntry() {
		tfLookUp.setText("");
		tfID.setText("");
		tfName.setText("");
		tfService.setText("");
		tfPhone.setText("");
		tfAddress.setText("");
		tfAverageCost.setText("");
		tfDeals.setText(""); 
		
	}
}
